"""Backend service for exposing ML models via FastAPI."""

from .detectors import (
    DetectionResult,
    EmotionDetector,
    ViolenceDetector,
    WeaponDetector,
)
