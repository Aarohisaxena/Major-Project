"""Wrapper classes around the existing ML models so they can be reused by the API."""

from __future__ import annotations

import logging
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional

import cv2
import numpy as np
from keras.models import load_model

LOGGER = logging.getLogger(__name__)


def _safe_path(path: Path) -> Path:
    if not path.exists():
        raise FileNotFoundError(f"Expected file not found: {path}")
    return path


@dataclass
class DetectionResult:
    label: str
    confidence: float
    metadata: Optional[Dict[str, float]] = None


class EmotionDetector:
    """Runs emotion detection using the existing CNN model and Haar cascade."""

    def __init__(self, model_path: Path, cascade_path: Path):
        self.model_path = _safe_path(model_path)
        self.cascade_path = _safe_path(cascade_path)
        self.model = load_model(str(self.model_path))
        self.face_classifier = cv2.CascadeClassifier(str(self.cascade_path))
        if self.face_classifier.empty():
            raise RuntimeError(f"Unable to load Haar cascade from {self.cascade_path}")
        self.emotion_labels = [
            "Angry",
            "Disgust",
            "Fear",
            "Happy",
            "Neutral",
            "Sad",
            "Surprise",
        ]
        self._lock = threading.Lock()

    def analyze_frame(self, frame: np.ndarray) -> DetectionResult:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = self.face_classifier.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)

        if len(faces) == 0:
            return DetectionResult(label="No Face Detected", confidence=0.0)

        results = []
        for (x, y, w, h) in faces:
            roi_gray = gray[y : y + h, x : x + w]
            roi_gray = cv2.resize(roi_gray, (48, 48), interpolation=cv2.INTER_AREA)
            roi = roi_gray.astype("float32") / 255.0
            roi = np.expand_dims(np.expand_dims(roi, axis=-1), axis=0)

            with self._lock:
                preds = self.model.predict(roi, verbose=0)[0]

            idx = int(np.argmax(preds))
            results.append(
                DetectionResult(
                    label=self.emotion_labels[idx],
                    confidence=float(preds[idx]),
                    metadata={"x": float(x), "y": float(y), "w": float(w), "h": float(h)},
                )
            )

        # Return the highest confidence face
        results.sort(key=lambda res: res.confidence, reverse=True)
        return results[0]


class ViolenceDetector:
    """Binary classifier that flags violent activity in the provided frame."""

    def __init__(self, model_path: Path, threshold: float = 0.9):
        self.model_path = _safe_path(model_path)
        self.model = load_model(str(self.model_path))
        self.threshold = threshold
        self._lock = threading.Lock()

    def analyze_frame(self, frame: np.ndarray) -> DetectionResult:
        resized = cv2.resize(frame, (128, 128)).astype("float32")
        resized = resized / 255.0
        resized = np.expand_dims(resized, axis=0)

        with self._lock:
            preds = self.model.predict(resized, verbose=0)[0]

        score = float(preds if np.isscalar(preds) else preds[0])
        label = "Violence Detected" if score >= self.threshold else "No Violence"

        return DetectionResult(label=label, confidence=score)
 

class WeaponDetector:
    """Multi-class classifier for weapon detection."""

    def __init__(self, model_path: Path):
        self.model_path = _safe_path(model_path)
        self.model = load_model(str(self.model_path))
        self.mean = np.array([123.68, 116.779, 103.939], dtype="float32")
        self.labels = [
            "Automatic Rifle",
            "Bazooka",
            "Handgun",
            "Knife",
            "Grenade Launcher",
            "Shotgun",
            "SMG",
            "Sniper",
            "Sword",
        ]
        self._lock = threading.Lock()

    def analyze_frame(self, frame: np.ndarray) -> DetectionResult:
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        resized = cv2.resize(rgb, (300, 300)).astype("float32")
        normalized = resized - self.mean
        normalized = np.expand_dims(normalized, axis=0)

        with self._lock:
            preds = self.model.predict(normalized, verbose=0)[0]

        idx = int(np.argmax(preds))
        print(float(preds[idx]))
        return DetectionResult(label=self.labels[idx], confidence=float(preds[idx]))




